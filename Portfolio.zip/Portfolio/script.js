

$(document).ready(function(){
  $(window).scroll(function(){
      // sticky navbar on scroll script
      if(this.scrollY > 10){
          $('.header').addClass("sticky");
      }else{
          $('.header').removeClass("sticky");
      }
    
  });

});


// Navbar
let menu =  document.querySelector('#menu-btn');
let navbar = document.querySelector('.navbar');

menu.onclick = () =>{
    menu.classList.toggle('fa-times');
    navbar.classList.toggle('active');    
}

window.onscroll = () =>{
    menu.classList.remove('fa-times');
    navbar.classList.remove('active');
}

// Text Animation
var words = document.getElementsByClassName('word');
var wordArray = [];
var currentWord = 0;

words[currentWord].style.opacity = 1;
for (var i = 0; i < words.length; i++) {
  splitLetters(words[i]);
}

function changeWord() {
  var cw = wordArray[currentWord];
  var nw = currentWord == words.length-1 ? wordArray[0] : wordArray[currentWord+1];
  for (var i = 0; i < cw.length; i++) {
    animateLetterOut(cw, i);
  }
  
  for (var i = 0; i < nw.length; i++) {
    nw[i].className = 'letter behind';
    nw[0].parentElement.style.opacity = 1;
    animateLetterIn(nw, i);
  }
  
  currentWord = (currentWord == wordArray.length-1) ? 0 : currentWord+1;
}

function animateLetterOut(cw, i) {
  setTimeout(function() {
		cw[i].className = 'letter out';
  }, i*80);
}

function animateLetterIn(nw, i) {
  setTimeout(function() {
		nw[i].className = 'letter in';
  }, 340+(i*80));
}

function splitLetters(word) {
  var content = word.innerHTML;
  word.innerHTML = '';
  var letters = [];
  for (var i = 0; i < content.length; i++) {
    var letter = document.createElement('span');
    letter.className = 'letter';
    letter.innerHTML = content.charAt(i);
    word.appendChild(letter);
    letters.push(letter);
  }
  
  wordArray.push(letters);
}

changeWord();
setInterval(changeWord, 4000);

// Popup1
const popupTrigger = document.querySelector('.popup-trigger');
const popup = document.querySelector('.popup');
const popupClose = document.querySelector('.popup__close');


popupTrigger.addEventListener('click', (e) => {
  popup.classList.add('show');
  document.body.style.cssText = `overflow: hidden;`;

});



popupClose.addEventListener('click', (e) => {
  popup.classList.remove('show');
  document.body.style.cssText= '';
});


// close on click on overlay

popup.addEventListener('click', (e) => {
  if (e.target === popup) {
    popup.classList.remove('show');
    document.body.style.cssText = '';
  }
});


// close on press of escape button

document.addEventListener('keydown', (e) => {
    if (e.code === "Escape" && popup.classList.contains('show')) {
      popup.classList.remove('show');
      document.body.style.cssText = '';
    }
  });


// Popup2
const popup2Trigger = document.querySelector('.popup2-trigger');
const popup2 = document.querySelector('.popup2');
const popup2Close = document.querySelector('.popup2__close');


popup2Trigger.addEventListener('click', (e) => {
  popup2.classList.add('show');
  document.body.style.cssText = `overflow: hidden;`;

});



popup2Close.addEventListener('click', (e) => {
  popup2.classList.remove('show');
  document.body.style.cssText= '';
});


// close on click on overlay

popup2.addEventListener('click', (e) => {
  if (e.target === popup2) {
    popup2.classList.remove('show');
    document.body.style.cssText = '';
  }
});


// close on press of escape button

document.addEventListener('keydown', (e) => {
    if (e.code === "Escape" && popup2.classList.contains('show')) {
      popup2.classList.remove('show');
      document.body.style.cssText = '';
    }
  });


// Popup3
const popup3Trigger = document.querySelector('.popup3-trigger');
const popup3 = document.querySelector('.popup3');
const popup3Close = document.querySelector('.popup3__close');


popup3Trigger.addEventListener('click', (e) => {
  popup3.classList.add('show');
  document.body.style.cssText = `overflow: hidden;`;

});



popup3Close.addEventListener('click', (e) => {
  popup3.classList.remove('show');
  document.body.style.cssText= '';
});


// close on click on overlay

popup3.addEventListener('click', (e) => {
  if (e.target === popup3) {
    popup3.classList.remove('show');
    document.body.style.cssText = '';
  }
});


// close on press of escape button

document.addEventListener('keydown', (e) => {
    if (e.code === "Escape" && popup3.classList.contains('show')) {
      popup3.classList.remove('show');
      document.body.style.cssText = '';
    }
  });


  // Project section slider
var TrandingSlider = new Swiper('.tranding-slider',{
  effect:'coverflow',
  grabCursor:true,
  centeredSlides:true,
  loop:true,
  slidesPerView:'auto',
  coverflowEffect:{
    rotate:0,
    stretch:0,
    depth:100,
    modifier:2.5,
  },
  pagination:{
    el:'.swiper-pagination',
    clickable:true,
  },
  navigation:{
    nextEl:'.swiper-button-next',
    prevEl:'.swiper-button-prev',

  }
})



// Contact section 
const inputs=document.querySelectorAll(".input");

function focusFunc(){
  let parent = this.parentNode;
  parent.classList.add("focus")
}

function blurFunc(){
  let parent = this.parentNode;
  if(this.value == ""){
    parent.classList.remove("focus")
  }

}

inputs.forEach((input) =>{
  input.addEventListener("focus",focusFunc);
  input.addEventListener("blur",blurFunc);
})







const year = document.querySelector('#current-year')
year.innerHTML = new Date().getFullYear()













